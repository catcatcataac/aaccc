#!/system/bin/sh
sleep 15
/data/adb/modules/HashIntegrityRescue/service