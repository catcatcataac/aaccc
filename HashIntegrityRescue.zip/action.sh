#!/system/bin/sh
TARGET_FILE="/data/adb/tricky_store/target.txt"
pm list packages | sed 's/package://g' > "$TARGET_FILE"
TEMP_FILE=$(mktemp)
while IFS= read -r line; do
    if [ -n "$line" ]; then
        echo "${line}!" >> "$TEMP_FILE"
    fi
done < "$TARGET_FILE"
mv "$TEMP_FILE" "$TARGET_FILE"
COUNT=$(grep -c . "$TARGET_FILE")
echo "已覆盖并处理 $COUNT 个包名到 $TARGET_FILE（均添加!）"