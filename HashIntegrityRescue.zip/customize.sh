#!/system/bin/sh
clear
SU_PATH=$(su -v)
echo 当前管理器版本 : $SU_PATH
if [ ! -d "/data/adb/tricky_store" ]; then
echo "未安装TrickyStore 安装失败"
exit 1
fi
echo 安装完成